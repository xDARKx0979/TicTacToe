# Tic Tac Toe Web Game

A simple Tic Tac Toe game that can be played in any web browser.

## Local Development

To run the game locally:

1. Clone or download this repository to your computer
2. Open the `index.html` file in your web browser

That's it! You can now play the game locally.

## Deploying Online

There are several easy ways to deploy this game so it can be accessed from any computer:

### Option 1: GitHub Pages (Free)

1. Create a GitHub account if you don't have one
2. Create a new repository
3. Upload all these files to your repository
4. Go to repository Settings > Pages
5. Set Source to "main" branch and click Save
6. Your site will be published at `https://yourusername.github.io/repository-name/`

### Option 2: Netlify (Free)

1. Create a Netlify account at [netlify.com](https://www.netlify.com/)
2. Drag and drop your project folder to the Netlify dashboard
3. Your site will be instantly published with a Netlify subdomain
4. You can add a custom domain later if desired

### Option 3: Vercel (Free)

1. Create a Vercel account at [vercel.com](https://vercel.com/)
2. Install Vercel CLI: `npm i -g vercel`
3. Navigate to your project directory in the terminal
4. Run `vercel` and follow the prompts
5. Your site will be deployed and accessible online

## Features

- Responsive design works on desktop and mobile
- Clear game status display
- Restart button to play again
- Visual feedback for X and O players

## Technologies Used

- HTML
- CSS
- JavaScript (Vanilla, no frameworks) 